
<?php
 $host = "localhost";
 $user = "root";
 $clave = "123456";
 $bd = "seguridad_usuarios_des";
 $conectar = mysqli_connect($host,$user,$clave,$bd);
 ?>

